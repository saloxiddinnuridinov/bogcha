<?php $__env->startSection('content'); ?>
    <?php if(session()->has('message')): ?>
        <div class="alert <?php echo e(session('error') ? 'alert-danger' : 'alert-success'); ?>">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">User</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>id</th>
                        <th>Ismi</th>
                        <th>Yoshi</th>
                        <th>guruhi</th>
                        <th>Ota-onasi</th>
                        <th>kelgan kuni</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->age); ?></td>
                            <td><?php echo e($user->category_id); ?></td>
                            <td><?php echo e($user->parent_id); ?></td>
                            <td><?php echo e($user->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('user.edit', ['id' => $user->id])); ?>" class="btn btn-info"><i class="fa fa-edit"></i></a>
                                <a href="<?php echo e(route('user.delete',['id' => $user->id])); ?>" class="btn btn-info"><i class="fa fa-trash"></i></a>
                                <a href="<?php echo e(route('user.send',['id' => $user->id])); ?>" class="btn btn-info"><i class="fa fa-envelope"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_asset'); ?>
    <!-- Page user plugins -->
    <script src="<?php echo e(asset('back/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('back/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page user custom scripts -->
    <script src="<?php echo e(asset('back/js/demo/datatables-demo.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\bogcha.loc\resources\views/admin/user.blade.php ENDPATH**/ ?>