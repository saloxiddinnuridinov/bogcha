<?php $__env->startSection('content'); ?>
    <?php if(session()->has('message')): ?>
        <div class="alert <?php echo e(session('error') ? 'alert-danger' : 'alert-success'); ?>">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Send Children</h6>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('send', ['id' => $user->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Ismi</label>
                    <input type="text" class="form-control" value="<?php echo e($user->name); ?>" required name="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Guruhi</label>
                    <input type="text" class="form-control"
                           value="<?php echo e(\App\Models\Category::find($user->category_id)->name); ?>" name="category_id">
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Ota-onasi</label>
                    <input type="text" class="form-control" value="<?php echo e(\App\Models\ChildrenParent::find($user->parent_id)->name); ?>"
                           required name="parent_id">
                    <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Keldi-Ketti</label>
                    <select name="xabar" id="" class="form-control">
                        <option value="ketdi">Ketdi</option>
                        <option value="keldi">Keldi</option>
                        <option value="kelmadi">Kelmadi</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Kim olib keldi | ketdi?</label>
                    <input type="text" class="form-control"  name="near">
                </div>
                <input type="hidden" name="userId" value="<?php echo e($user->id); ?>">
                <input type="hidden" name="parentId" value="<?php echo e(\App\Models\ChildrenParent::find($user->parent_id)->id); ?>">
                <div class="form-group">
                    <button class="btn btn-success" type="submit">Send</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\bogcha.loc\resources\views/admin/send.blade.php ENDPATH**/ ?>